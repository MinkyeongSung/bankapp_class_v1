package com.tenco.bankapp.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TestController {

}
