package com.tenco.bankapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybankappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybankappApplication.class, args);
	}

}
