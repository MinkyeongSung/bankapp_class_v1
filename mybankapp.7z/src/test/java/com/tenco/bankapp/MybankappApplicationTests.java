package com.tenco.bankapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybankappApplicationTests {

	@Test
	void contextLoads() {
	}

}
